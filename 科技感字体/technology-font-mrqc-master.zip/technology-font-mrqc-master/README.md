# technology-font-mrqc  
"technology-font-mrqc"字体只包含0-9十个数字，最开始制作的初衷，是为了Coding的码力值展示页面可以引入一个极小且富含科技感的字体而设计的。  
开源出来的目的是为了可以在此基础上更加进一步的完善这个字体，方便之后的设计师或程序员在完成相应风格的页面的时候可以有直接可以引用的字体。  
而且这是一个免费的字体，允许任何人用于任何用途。
### <a href="https://murongqiaochu.github.io/technology-font-mrqc/">静态展示页面</a>  
***
The "technology-font-mrqc" font contains only 0-9 digits, and the original intention was to create a code for “Coding.net” display pages that could introduce a font and high-tech font.

The purpose of open source can be on the basis of further perfecting the font, convenient after designer or programmer at the completion of the corresponding style of page can have a direct can refer to the font.

And it's a free font that allows anyone to use it for any purpose.  
### <a href="https://murongqiaochu.github.io/technology-font-mrqc/">A static page</a>  
***
2017年07月17日改动：添加“：:”两个标点符号  
2017年07月17日改动：添加静态展示页面
